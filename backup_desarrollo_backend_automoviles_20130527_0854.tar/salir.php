<?php
session_start();
session_destroy();
?>
<html>
<head>
<title>Refrescar la URL</title>
<META HTTP-EQUIV="REFRESH" CONTENT="0;URL=login.php"></head>
</head>
<body>


</body>
</html>