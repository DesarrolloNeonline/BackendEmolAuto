<?php
include ('seguridad.php');   
require_once 'head-home.php';
echo '</head>';
require_once 'menu.php';
?>
<div id='content'>
		<div id='formulario'>
			<div id='pagina'>
			</div>
		</div>
		<br>
		<div id='footer' style='text-align:center;	margin: 10px 0px;'>
			<span class='label label-info'><b>Emol Autom&oacute;viles 2013 - Versi&oacute;n 1.0</b></span><br>
			<span  style="font-size:8px; "><b>Compatibilidad  Google Chrome - Mozilla FireFox</b></span>
		</div>
</div>
</body>
</html>
	
