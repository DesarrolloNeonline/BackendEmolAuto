 <?php
echo "
<!DOCTYPE html>
<html>
<head>
<title>Emol Automoviles</title>
<link href='../css/default.css' rel='stylesheet'>
<link href='../css/bootstrap.css' rel='stylesheet'>
<link href='../css/bootstrap.min.css' rel='stylesheet'>
<link href='../css/bootstrap-responsive.css' rel='stylesheet'>
<link href='../css/bootstrap-responsive.min.css' rel='stylesheet'>
<script type='text/javascript' src='../js/jquery-1.2.3.min.js'></script>
<script type='text/javascript' src='../js/bootstrap.js'></script>
<script type='text/javascript' src='../js/bootstrap.min.js'></script>
<script type='text/javascript' src='../js/jquery.js'></script>
";
?>