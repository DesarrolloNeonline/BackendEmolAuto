$(document).ready(function() {
    $(".tablesorter").tablesorter().tablesorterPager({container: $("#pager")});
    $(".tablesorter2").tablesorter();
});