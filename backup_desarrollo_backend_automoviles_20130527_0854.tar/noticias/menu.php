<body>
	<div id="content">
		<div id="tabla2"> 
	        <a href="http://club.mersap.com/emol_automovil_merge/">
				<img src="../images/logo.jpg" alt="Emol Automoviles">
			</a>
			<div id="salir">
				<form action="../salir.php" method="POST">
						<td align="right">
				<br><button type="submit"  align ="center" class="btn btn-primary" name="submit" value="LOG IN"> <i class=""></i>Cerrar Sesi�n </button>
						</td>
				</form>
			</div>
		</div>						
	</div>
	<br>
	<script src="../js/bootstrap-dropdown.js"></script>
	<div class="navbar">
		<div class="navbar-inner">
			<div class="container">
				<ul class="nav">
					<li>				
						<a href="./../index.php" ><i class="icon-home icon-white"></i> Home</a>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle"	data-toggle="dropdown"	href="#">
							Noticias
							<b class="caret"></b>
						</a>
						<ul class="dropdown-menu">
							<li>
								<a href="crear_noticia.php">
									Crear Noticia
								</a>
							</li>
							<li>
								<a href="listar_noticias.php">
									Lista de Noticias
								</a>
							</li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
	</div>