<?php
require_once '../head.php';
?>
<script type="text/javascript" src="../js/jquery-ui-1.8.17.custom.min.js"></script>
<link type="text/css" href="../css/smoothness/jquery-ui-1.8.17.custom.css" rel="Stylesheet" />
</head>
	<?php 
		require_once 'menu.php';
		include('../config/connect.php'); 
		
		try 
		{
			$sql_destacado_1  = 'select bp_concesionario from concesionarios_destacados where id_destacado = 1';
			$result_destacado_1 = mysql_query($sql_destacado_1);
			$array_destacado_1 = mysql_fetch_array($result_destacado_1);
			$bp_concesionario_1 =  $array_destacado_1[0];

			$sql_concesionario_1  = 'select nombre_fantasia, RUT, local, logo_chico from automoviles.concesionario where bp_concesionario="'.$bp_concesionario_1.'"';
			$result_concesionario_1 = mysql_query($sql_concesionario_1);
			$array_concesionario_1 = mysql_fetch_array($result_concesionario_1);
			$nombre_concesionario_1 = $array_concesionario_1[0];
			$rut_1 				    = $array_concesionario_1[1];
			$local_1					= $array_concesionario_1[2];
		    $logo_1 				= $array_concesionario_1[3];

		}
		catch(PDOException $e) 
		{
			error_log($e->getMessage());
			die('Error al seleccionar primer destacado');
		}
		try 
		{
			$sql_destacado_2  = 'select bp_concesionario from concesionarios_destacados where id_destacado = 2';
			$result_destacado_2 = mysql_query($sql_destacado_2);
			$array_destacado_2 = mysql_fetch_array($result_destacado_2);
			$bp_concesionario_2 =  $array_destacado_2[0];

			$sql_concesionario_2  = 'select nombre_fantasia, RUT, local, logo_chico from automoviles.concesionario where bp_concesionario="'.$bp_concesionario_2.'"';
			$result_concesionario_2 = mysql_query($sql_concesionario_2);
			$array_concesionario_2 = mysql_fetch_array($result_concesionario_2);
			$nombre_concesionario_2 = $array_concesionario_2[0];
			$rut_2 				    = $array_concesionario_2[1];
			$local_2				= $array_concesionario_2[2];
		    $logo_2 				= $array_concesionario_2[3];
		}
		catch(PDOException $e) 
		{
			error_log($e->getMessage());
			die('Error al seleccionar segundo destacado 2');
		}
		try
		{
			$sql_destacado_3  = 'select bp_concesionario from concesionarios_destacados where id_destacado = 3';
			$result_destacado_3 = mysql_query($sql_destacado_3);
			$array_destacado_3 = mysql_fetch_array($result_destacado_3);
			$bp_concesionario_3 =  $array_destacado_3[0];

			$sql_concesionario_3  = 'select nombre_fantasia, RUT, local, logo_chico from automoviles.concesionario where bp_concesionario="'.$bp_concesionario_3.'"';
			$result_concesionario_3 = mysql_query($sql_concesionario_3);
			$array_concesionario_3 = mysql_fetch_array($result_concesionario_3);
			$nombre_concesionario_3 = $array_concesionario_3[0];
			$rut_3 				    = $array_concesionario_3[1];
			$local_3				= $array_concesionario_3[2];
		    $logo_3				= $array_concesionario_3[3];
		

		}
		catch(PDOException $e) 
		{
			error_log($e->getMessage());
			die('Error al seleccionar tercer destacado 3');
		}
		try
		{
			$sql_destacado_4  = 'select bp_concesionario from concesionarios_destacados where id_destacado = 4';
			$result_destacado_4 = mysql_query($sql_destacado_4);
			$array_destacado_4 = mysql_fetch_array($result_destacado_4);
			$bp_concesionario_4 =  $array_destacado_4[0];

			$sql_concesionario_4  = 'select nombre_fantasia, RUT, local, logo_chico from automoviles.concesionario where bp_concesionario="'.$bp_concesionario_4.'"';
			$result_concesionario_4 = mysql_query($sql_concesionario_4);
			$array_concesionario_4 = mysql_fetch_array($result_concesionario_4);
			$nombre_concesionario_4 = $array_concesionario_4[0];
			$rut_4 				    = $array_concesionario_4[1];
			$local_4				= $array_concesionario_4[2];
		    $logo_4				= $array_concesionario_4[3];
		}
		catch(PDOException $e) 
		{
			error_log($e->getMessage());
			die('Error al seleccionar cuarto destacado 4');
		}
		try
		{
			$sql_destacado_5  = 'select bp_concesionario from concesionarios_destacados where id_destacado = 5';
			$result_destacado_5 = mysql_query($sql_destacado_5);
			$array_destacado_5 = mysql_fetch_array($result_destacado_5);
			$bp_concesionario_5 =  $array_destacado_5[0];

			$sql_concesionario_5  = 'select nombre_fantasia, RUT, local, logo_chico from automoviles.concesionario where bp_concesionario="'.$bp_concesionario_5.'"';
			$result_concesionario_5 = mysql_query($sql_concesionario_5);
			$array_concesionario_5 = mysql_fetch_array($result_concesionario_5);
			$nombre_concesionario_5 = $array_concesionario_5[0];
			$rut_5 				    = $array_concesionario_5[1];
			$local_5				= $array_concesionario_5[2];
		    $logo_5				= $array_concesionario_5[3];
		}
		catch(PDOException $e) 
		{
			error_log($e->getMessage());
			die('Error al seleccionar quinto destacado');
		}
		try
		{
			$sql_destacado_6  = 'select bp_concesionario from concesionarios_destacados where id_destacado = 6';
			$result_destacado_6 = mysql_query($sql_destacado_6);
			$array_destacado_6 = mysql_fetch_array($result_destacado_6);
			$bp_concesionario_6 =  $array_destacado_6[0];

			$sql_concesionario_6  = 'select nombre_fantasia, RUT, local, logo_chico from automoviles.concesionario where bp_concesionario="'.$bp_concesionario_6.'"';
			$result_concesionario_6 = mysql_query($sql_concesionario_6);
			$array_concesionario_6 = mysql_fetch_array($result_concesionario_6);
			$nombre_concesionario_6 = $array_concesionario_6[0];
			$rut_6 				    = $array_concesionario_6[1];
			$local_6				= $array_concesionario_6[2];
		    $logo_6				= $array_concesionario_6[3];
		}
		catch(PDOException $e) 
		{
			error_log($e->getMessage());
			die('Error al seleccionar sexto destacado');
		}
	?>
	<body>	
		<div id="content">
			<div id="formulario">
				<div id="pagina">
					<h2>Formulario de Actualizaci&oacute;n de Concesionarios Destacados</h2>
				</div>
			</div>
			<div id="tabla">
				<div id="row">
					<div class="span13">
					<form  name = "form" action="procesa_destacado.php" method="POST" id="myForm" enctype="multipart/form-data">
					<div class="form-actions">
						<div id="navmenu">
											<div>
												 <label class="description" for="element">Concesionarios Destacados</label><br> 	
											</div>
											<div>
												<strong>BP Concesionario -1</strong>
												<input id="element" name="destacado-1" class="element text medium" type="text" style="width:150px" maxlength="1500" placeholder="Destacado 1" value="<?php echo $bp_concesionario_1;?>"/>
												<img style="width: 117px; height: 50px;margin-left: 20px;" src="<?php echo $folder_frontend;?>/upload/concesionarios/<?php echo $logo_1;?>" />
												<strong><?php echo $nombre_concesionario_1;?> </strong><strong><?php echo $rut_1.$local_1;?></strong>
											</div>
											<div>
												<strong>BP Concesionario -2</strong>
												<input id="element" name="destacado-2" class="element text medium" type="text" style="width:150px" maxlength="1500" placeholder="Destacado 2" value="<?php echo $bp_concesionario_2;?>"/> 
												<img style="width: 117px; height: 50px;margin-left: 20px;" src="<?php echo $folder_frontend;?>/upload/concesionarios/<?php echo $logo_2;?>" />
												<strong><?php echo $nombre_concesionario_2;?> </strong><strong><?php echo $rut_2.$local_2;?></strong>
											</div>
											<div>
												<strong>BP Concesionario -3</strong>
												<input id="element" name="destacado-3" class="element text medium" type="text" style="width:150px" maxlength="1500" placeholder="Destacado 3" value="<?php echo $bp_concesionario_3;?>"/> 
												<img style="width: 117px; height: 50px;margin-left: 20px;" src="<?php echo $folder_frontend;?>/upload/concesionarios/<?php echo $logo_3;?>" />
												<strong><?php echo $nombre_concesionario_3;?> </strong><strong><?php echo $rut_3.$local_3;?></strong>
											</div>
											<div>
												<strong>BP Concesionario -4</strong>
												<input id="element" name="destacado-4" class="element text medium" type="text" style="width:150px" maxlength="1500" placeholder="Destacado 4" value="<?php echo $bp_concesionario_4;?>"/> 
												<img style="width: 117px; height: 50px;margin-left: 20px;" src="<?php echo $folder_frontend;?>/upload/concesionarios/<?php echo $logo_4;?>" />
												<strong><?php echo $nombre_concesionario_4;?> </strong><strong><?php echo $rut_4.$local_4;?></strong>
											</div>
											<div>
												<strong>BP Concesionario -5</strong>
												<input id="element" name="destacado-5" class="element text medium" type="text" style="width:150px" maxlength="1500" placeholder="Destacado 5" value="<?php echo $bp_concesionario_5;?>"/> 
												<img style="width: 117px; height: 50px;margin-left: 20px;" src="<?php echo $folder_frontend;?>/upload/concesionarios/<?php echo $logo_5;?>" />
												<strong><?php echo $nombre_concesionario_5;?> </strong><strong><?php echo $rut_5.$local_5;?></strong>
											</div>
											<div>
												<strong>BP Concesionario -6</strong>
												<input id="element" name="destacado-6" class="element text medium" type="text" style="width:150px" maxlength="1500" placeholder="Destacado 6" value="<?php echo $bp_concesionario_6;?>"/> 
												<img style="width: 117px; height: 50px;margin-left: 20px;" src="<?php echo $folder_frontend;?>/upload/concesionarios/<?php echo $logo_6;?>" />
												<strong><?php echo $nombre_concesionario_6;?> </strong><strong><?php echo $rut_6.$local_6;?></strong>
											</div>
						</div>
						<div id="navmenu" style="margin-top:40px">
							<ul>
								<li> 
									<button type='submit' style="margin-left: 130px;" class= 'btn btn-success' name='submit' value =''>Guardar</button>
								</li>
							</ul>
						</div>
					</form>
					</div>
				</div>
			</div>
		</div>
<?php	
	mysql_close($conn);	?> 
	</body>
</html>